# kola-video (Remotion)
npm install
npx remotion studio src/index.ts   # প্রিভিউ  (npm run studio)
npx remotion render src/index.ts Kola out/kola.mp4   # রেন্ডার (npm run render)
