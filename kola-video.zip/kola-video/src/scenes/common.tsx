import React from 'react';
import {useCurrentFrame} from 'remotion';
import {FPS, W, H} from '../config';
import {ease} from '../Ui';

export const useT = (start: number) => {
  const f = useCurrentFrame();
  return {f, t: start + f / FPS};
};

export const At: React.FC<{x: number; y: number; children: React.ReactNode; z?: number; style?: React.CSSProperties}> = ({x, y, children, z, style}) => (
  <div style={{position: 'absolute', left: x, top: y, zIndex: z, ...style}}>{children}</div>
);

// সিনের শুরুতে হালকা উইপ ট্রানজিশন
export const Wipe: React.FC<{f: number; color?: string}> = ({f, color = '#1a1a2e'}) => {
  const p = ease(f / FPS, 0, 0.4);
  if (p >= 1) return null;
  return <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, background: color, transform: `translateX(${-p * 100}%)`, zIndex: 50}} />;
};

export const Zoom: React.FC<{scale: number; ox: number; oy: number; children: React.ReactNode}> = ({scale, ox, oy, children}) => (
  <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, transform: `scale(${scale})`, transformOrigin: `${ox}px ${oy}px`}}>{children}</div>
);
