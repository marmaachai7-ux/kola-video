import React from 'react';
import {Character, LOOKS} from '../Character';
import {MotionBg, Street} from '../Bg';
import {Card, Show, Stamp, Thought, clamp01, ease, fontFamily, mk} from '../Ui';
import {Cross, Heart, LaughFace, Stairs, Steering} from '../Icons';
import {At, Wipe, useT} from './common';
import {W, H} from '../config';

export const Scene6: React.FC = () => {
  const {f, t} = useT(111.58);
  const partA = t < 121.2;
  const shown = Math.min(5, Math.floor(Math.max(0, t - 125.4) / 0.62) + 1);
  const fadeOut = clamp01((t - 132.4) / 0.85);
  const reach = ease(t, 129.4, 130.6);

  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden', background: '#000'}}>
      {partA ? (
        <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H}}>
          <Street f={0} tone="day" sign />
          {/* রাকিব */}
          <At x={40} y={610}>
            <Character look={LOOKS.rakib} width={250} f={f} seed={14} expr={t >= 113.4 ? 'laugh' : 'happy'} pose={t >= 113.4 ? 'cheer' : 'idle'} eyeX={0.4} />
          </At>
          {/* ইমরান */}
          <At x={400} y={556}>
            <Character
              look={LOOKS.imranOwner} width={300} f={f} seed={15} flip
              expr={t >= 117.1 && t < 119.6 ? 'sad' : t >= 119.6 ? 'determined' : 'happy'}
              pose={t < 116 ? 'give' : t >= 117.1 ? 'think' : 'idle'}
            />
          </At>
          <Stamp t={t} a={113.4} b={116.0} x={360} y={300} text="বিনা খরচে!" color="#2f7d4a" />
          <Show t={t} a={113.7} b={116.0} x={360} y={470} float={8}><Steering s={170} f={f} /></Show>
          <Show t={t} a={114.2} b={116.0} x={160} y={420} float={6}><Heart s={70} /></Show>
          <Show t={t} a={114.4} b={116.0} x={560} y={400} float={6}><Heart s={60} /></Show>

          <Thought t={t} a={117.1} b={121.2} cx={500} cy={330} rx={150} ry={105} tail={[550, 608]}>
            <div style={{position: 'relative', width: 140, height: 140}}>
              <LaughFace s={130} f={f} />
              {t >= 119.7 && (
                <div style={{position: 'absolute', left: 30, top: 30, transform: `scale(${clamp01((t - 119.7) / 0.2)})`}}>
                  <Cross s={90} />
                </div>
              )}
            </div>
          </Thought>
        </div>
      ) : (
        <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H}}>
          <MotionBg f={f} c1="#1f6a4e" c2="#0d2c24" />

          {/* কার্ড ১: স্বপ্ন কেউ তুলে দেয় না */}
          <Card t={t} a={121.8} b={125.4} x={360} y={560} w={580}>
            <div style={{display: 'flex', justifyContent: 'center', gap: 18, marginBottom: 12}}>
              <Heart s={90} color="#f2b92f" />
              <Cross s={90} />
            </div>
            <div style={{fontFamily, fontSize: 48, lineHeight: 1.25}}>{mk('*স্বপ্ন* কেউ হাতে তুলে দেয় না')}</div>
          </Card>

          {/* সিঁড়ি */}
          {t >= 125.4 && (
            <At x={140} y={700}><Stairs steps={5} shown={shown} w={420} /></At>
          )}
          <Card t={t} a={125.5} b={129.1} x={360} y={330} w={600}>
            <div style={{fontFamily, fontSize: 46, lineHeight: 1.25}}>{mk('*রোজকার* ছোট ছোট কাজই তাকে কাছে আনে')}</div>
          </Card>

          {/* শেষ শিক্ষা */}
          <Card t={t} a={129.2} b={133.3} x={360} y={300} w={620}>
            <div style={{fontFamily, fontSize: 46, lineHeight: 1.3}}>{mk('আসল *জয়* হলো পেছনের জনের জন্য *সিঁড়িটা* ধরে রাখা')}</div>
          </Card>
          {t >= 129.4 && (
            <div>
              <At x={425} y={407}>
                <Character look={LOOKS.imranOwner} width={170} f={f} seed={16} flip expr="happy" pose={reach > 0.5 ? 'give' : 'idle'} float={false} />
              </At>
              <At x={205} y={659}>
                <Character look={LOOKS.rakib} width={130} f={f} seed={17} expr="happy" pose={reach > 0.5 ? 'cheer' : 'idle'} float={false} />
              </At>
              <Show t={t} a={130.6} b={133.3} x={560} y={560} float={8}><Heart s={60} /></Show>
            </div>
          )}
        </div>
      )}
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, background: `rgba(0,0,0,${fadeOut})`}} />
      <Wipe f={f} />
    </div>
  );
};
