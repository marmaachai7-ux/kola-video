import React from 'react';
import {Character, LOOKS, extraLook, mouthAt} from '../Character';
import {Street} from '../Bg';
import {Bubble, Card, NamePill, Show, clamp01, ease, fontFamily, mk} from '../Ui';
import {Bill, BusSide, Gear} from '../Icons';
import {At, Wipe, Zoom, useT} from './common';
import {W, H} from '../config';

export const Scene3: React.FC = () => {
  const {f, t} = useT(42.14);
  const broken = t >= 43.7;
  const jolt = t > 43.7 && t < 44.8 ? Math.sin(f * 2.2) * 6 : 0;
  const tX = 800 - 390 * ease(t, 55.6, 56.5);
  const tSpeak = t >= 57.2 && t < 59.9;
  const zoom = 1 + 0.25 * ease(t, 60.2, 63.0);
  const worried = t < 62.0;

  // ঋণ/বিলের বার চার্ট
  const bars = [0.25, 0.4, 0.62, 0.9].map((v, i) => v * clamp01((t - 48.7 - i * 0.35) / 0.5));
  // লাল কালির দাগ
  const ink = ease(t, 52.8, 54.8);

  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden'}}>
      <Zoom scale={zoom} ox={160} oy={680}>
        <Street f={0} tone="dusk" sign />
        <At x={60 + jolt} y={780}>
          <BusSide w={600} f={f} smoke={broken} wheelSpin={broken ? 0 : 6} />
        </At>

        {/* নেমে যাওয়া যাত্রী */}
        {t >= 45.6 && t < 50 && [0, 1, 2].map((i) => {
          const p = clamp01((t - 45.6 - i * 0.35) / 3.2);
          return (
            <At key={i} x={520 - 520 * p - i * 40} y={812} style={{opacity: 1 - clamp01((p - 0.85) / 0.15)}}>
              <Character look={extraLook(i + 4)} width={150} f={f} seed={i} walk={24} float={false} flip />
            </At>
          );
        })}

        {/* ইমরান */}
        <At x={-10} y={550}>
          <Character
            look={LOOKS.imranOwner} width={300} f={f} seed={7}
            expr={worried ? 'worried' : 'determined'}
            pose={t >= 59.9 ? 'think' : 'idle'}
            eyeX={t >= 55.6 && t < 60 ? 0.8 : 0}
            tremble={t >= 43.7 && t < 44.8 ? 3 : 0}
          />
        </At>

        {/* ব্যবসায়ী */}
        {t >= 55.5 && (
          <At x={tX} y={550}>
            <Character look={LOOKS.trader} width={300} f={f} seed={8} expr="happy" mouth={tSpeak ? mouthAt(f, true) : 0} pose={tSpeak ? 'open' : 'idle'} flip />
          </At>
        )}
        <NamePill t={t} a={55.8} b={57.0} x={560} y={560} text="ব্যবসায়ী" color="#6b6f7a" />
        <Bubble
          t={t} a={57.0} b={60.0} x={40} y={200} w={640} h={200}
          text="ভাই, ভালো *দাম* দেব। এই ঝামেলা ছেড়ে দিন।"
          tail={[560, 605]} fs={40}
        />
      </Zoom>

      {/* থেমে যাওয়ার কাউন্টার */}
      <Card t={t} a={43.8} b={46.0} x={360} y={330} w={400} bg="#fff1f0">
        <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16}}>
          <div style={{fontFamily, fontSize: 120, color: '#d8362f', lineHeight: 1}}>৩</div>
          <div style={{fontFamily, fontSize: 44, lineHeight: 1.15, textAlign: 'left'}}>বার মাঝপথে<br />{mk('*থেমে* গেল')}</div>
        </div>
      </Card>

      {/* বিল কার্ড */}
      <Card t={t} a={48.3} b={52.1} x={360} y={330} w={420}>
        <div style={{display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 22}}>
          <Bill s={130} />
          <svg width={160} height={130}>
            {bars.map((v, i) => <rect key={i} x={i * 40} y={130 - v * 125} width={30} height={v * 125} rx={5} fill={['#e8b66a', '#e8873a', '#e0603a', '#d8362f'][i]} stroke="#222" strokeWidth={3} />)}
          </svg>
        </div>
        <div style={{fontFamily, fontSize: 40, marginTop: 8}}>{mk('মেকানিকের *বিল* বাড়ছে')}</div>
      </Card>

      {/* খাতার লাল দাগ */}
      <Card t={t} a={52.7} b={55.4} x={360} y={330} w={420}>
        <div style={{fontFamily, fontSize: 38, textAlign: 'left', padding: '0 8px'}}>হিসাবের খাতা</div>
        <svg width={360} height={110} style={{display: 'block', margin: '6px auto'}}>
          {[30, 60, 90].map((y) => <line key={y} x1={0} y1={y} x2={360} y2={y} stroke="#9aa3ad" strokeWidth={2} />)}
          <path d="M10 80 L60 50 L110 66 L170 30 L230 56 L300 14" fill="none" stroke="#d8362f" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={520} strokeDashoffset={520 * (1 - ink)} />
        </svg>
        <div style={{fontFamily, fontSize: 38}}>{mk('*লাল* কালির দাগ')}</div>
      </Card>

      {/* ইঞ্জিনের চিন্তা */}
      <Show t={t} a={60.2} b={63.3} x={300} y={420} float={6}><Gear s={120} f={f} /></Show>
      <Show t={t} a={60.5} b={63.3} x={450} y={360} float={6}><Gear s={80} f={-f} color="#c9a05a" /></Show>
      <Wipe f={f} />
    </div>
  );
};
