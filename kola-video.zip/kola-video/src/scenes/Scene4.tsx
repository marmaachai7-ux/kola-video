import React from 'react';
import {Character, LOOKS, extraLook, mouthAt} from '../Character';
import {BusInterior, Garage, Street} from '../Bg';
import {Bubble, Card, Show, clamp01, ease, fontFamily, mk} from '../Ui';
import {BagProp, BusSide, Check, Clock, Cross, Gear, Heart, HeavyBagProp, WrenchProp} from '../Icons';
import {At, Wipe, useT} from './common';
import {W, H} from '../config';

const phase = (t: number, a: number, b: number): React.CSSProperties => ({
  position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden',
  opacity: clamp01((t - a) / 0.35) * clamp01((b - t) / 0.35),
  display: t >= a - 0.01 && t <= b + 0.01 ? 'block' : 'none',
});

const Engine: React.FC<{f: number}> = ({f}) => (
  <svg width={300} height={270} viewBox="0 0 300 270">
    <rect x={0} y={30} width={300} height={220} rx={22} fill="#c8453a" stroke="#222" strokeWidth={5} />
    <rect x={26} y={62} width={248} height={160} rx={10} fill="#33363c" stroke="#222" strokeWidth={4} />
    {[50, 100, 150, 200].map((x, i) => (
      <g key={x}>
        <rect x={x} y={86} width={34} height={60 + Math.abs(Math.sin(f / 5 + i)) * 14} rx={6} fill="#9aa3ad" stroke="#222" strokeWidth={3} />
        <rect x={x - 4} y={80} width={42} height={12} rx={4} fill="#6b7280" stroke="#222" strokeWidth={3} />
      </g>
    ))}
    <rect x={40} y={184} width={220} height={16} rx={8} fill="#e8873a" stroke="#222" strokeWidth={3} />
  </svg>
);

export const Scene4: React.FC = () => {
  const {f, t} = useT(63.36);
  const dayA = (t >= 66.2 && t < 68.4) || (t >= 70.6 && t < 72.4) ? 1 : 0;
  const bar = ease(t, 70.6, 73.2);
  const jSpeak = t >= 85.6 && t < 88.5;

  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden', background: '#000'}}>
      {/* ক: গ্যারেজ */}
      <div style={phase(t, 63.3, 74.0)}>
        <Garage f={f} day={dayA} />
        <At x={380} y={720}><Engine f={f} /></At>
        <At x={440} y={780}><Gear s={110} f={f} /></At>
        <At x={10} y={550}>
          <Character
            look={LOOKS.imranGarage} width={330} f={f} seed={9}
            expr={t >= 72.3 ? 'happy' : t >= 67.8 && t < 70 ? 'worried' : 'determined'}
            pose={Math.floor(t * 1.4) % 2 ? 'work' : 'carry'}
            rightProp={<WrenchProp />}
          />
        </At>
        <Show t={t} a={68.3} b={69.8} x={560} y={460}><Cross s={110} /></Show>
        <Show t={t} a={69.9} b={70.4} x={560} y={460}><Gear s={110} f={f} /></Show>
        <Card t={t} a={70.5} b={74.0} x={360} y={330} w={440}>
          <div style={{fontFamily, fontSize: 40, marginBottom: 12}}>{mk('ছোটখাটো গোলমাল সারাতে *শিখে* গেল')}</div>
          <div style={{height: 34, borderRadius: 17, background: '#e3dccb', border: '4px solid #222', overflow: 'hidden'}}>
            <div style={{width: `${bar * 100}%`, height: '100%', background: '#3fae5a'}} />
          </div>
          <div style={{marginTop: 10, display: 'flex', justifyContent: 'center'}}>{bar > 0.98 ? <Check s={64} /> : <Gear s={64} f={f} />}</div>
        </Card>
      </div>

      {/* খ: সময়মতো বাস, যাত্রী, ভারী ব্যাগ */}
      <div style={phase(t, 73.8, 82.2)}>
        <Street f={f} tone="day" />
        <At x={60} y={780 + Math.sin(f / 4) * 2}><BusSide w={600} f={f} body="#3fae7a" /></At>
        <Show t={t} a={74.3} b={76.2} x={250} y={330}><Clock s={170} hr={30} min={0} /></Show>
        <Show t={t} a={74.9} b={76.2} x={370} y={420}><Check s={90} /></Show>
        <At x={20} y={550}>
          <Character
            look={LOOKS.imranOwner} width={300} f={f} seed={10} expr="happy"
            pose={t < 78.3 ? 'wave' : 'give'}
            rightProp={t >= 78.3 ? <HeavyBagProp /> : undefined}
          />
        </At>
        <At x={390} y={560}>
          <Character look={extraLook(2)} width={280} f={f} seed={11} expr="happy" pose={t >= 79 ? 'open' : 'idle'} flip />
        </At>
        {[[470, 400, 76.2], [580, 450, 76.6], [400, 470, 77.0]].map(([x, y, a], i) => (
          <Show key={i} t={t} a={a} b={78.4} x={x} y={y} float={7}><Heart s={64} /></Show>
        ))}
      </div>

      {/* গ: বাসের ভেতর, কাকা জলিল */}
      <div style={phase(t, 82.0, 90.4)}>
        <BusInterior f={f} layer="back" />
        <At x={30} y={505}><Character look={extraLook(1)} crop="bust" width={210} f={f} seed={1} /></At>
        <At x={350 + 400 * (1 - ease(t, 82.2, 83.4))} y={500}>
          <Character
            look={LOOKS.jolil} crop="bust" width={330} f={f} seed={3}
            expr={jSpeak ? 'surprised' : t >= 88.5 ? 'happy' : 'neutral'}
            mouth={jSpeak ? mouthAt(f, true) : 0} pose={jSpeak ? 'open' : 'idle'}
          />
        </At>
        <BusInterior f={f} layer="front" />
        <At x={10} y={720}>
          <Character
            look={LOOKS.imranOwner} crop="knee" width={380} f={f} seed={4}
            expr={t >= 88.9 ? 'happy' : 'neutral'} pose="hang" leftProp={<BagProp />}
          />
        </At>
        <Bubble t={t} a={84.9} b={88.9} x={50} y={175} w={620} h={210} text="এই বাসটা কখনো *দেরি* করে না, তাই না?" tail={[520, 525]} fs={42} />
      </div>
      <Wipe f={f} />
    </div>
  );
};
