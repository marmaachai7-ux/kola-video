import React from 'react';
import {Character, LOOKS, mouthAt} from '../Character';
import {Street} from '../Bg';
import {Bubble, NamePill, Show, ease} from '../Ui';
import {BusSide, PolyProp, Question, Steering} from '../Icons';
import {At, Wipe, useT} from './common';
import {W, H} from '../config';

export const Scene5: React.FC = () => {
  const {f, t} = useT(90.4);
  const busX = 520 - 1300 * ease(t, 91.0, 96.0);
  const running = t < 96.0;
  const rakX = running ? 700 - 1000 * ease(t, 91.3, 96.0) : -260 + 320 * ease(t, 96.3, 97.8);
  const walking = t >= 96.3 && t < 97.9;

  const iSpeak = (t >= 97.8 && t < 99.4) || (t >= 105.9 && t < 107.7) || (t >= 107.8 && t < 111.4);
  const rSpeak = (t >= 100.3 && t < 103.2) || (t >= 103.5 && t < 105.8);
  const rExpr = t < 97.8 ? 'tired' : t < 100.2 ? 'neutral' : t < 103.3 ? 'shy' : t < 105.9 ? 'sad' : t >= 110.2 ? 'happy' : 'neutral';

  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden'}}>
      <Street f={running ? f : 0} tone="dusk" sign />
      <At x={busX} y={780}><BusSide w={560} f={f} wheelSpin={14} /></At>

      {/* রাকিব */}
      <At x={rakX} y={734}>
        <Character
          look={LOOKS.rakib} width={200} f={f} seed={12} flip={running}
          walk={running ? 38 : walking ? 18 : 0} float={!running && !walking}
          expr={rExpr as any} mouth={rSpeak ? mouthAt(f, true) : 0}
          pose={running ? 'carry' : 'idle'} tremble={running ? 0.8 : 0}
          rightProp={<PolyProp />}
        />
      </At>
      {/* ইমরান */}
      <At x={400} y={556}>
        <Character
          look={LOOKS.imranOwner} width={300} f={f} seed={13} flip
          expr={t >= 105.9 ? 'happy' : t >= 97.8 ? 'happy' : 'neutral'}
          mouth={iSpeak ? mouthAt(f, true) : 0}
          pose={iSpeak ? (t >= 107.7 ? 'open' : 'give') : 'idle'}
        />
      </At>

      <NamePill t={t} a={93.0} b={96.6} x={Math.max(120, Math.min(560, rakX + 100))} y={700} text="রাকিব · ১০ বছর" color="#e0762e" />

      <Bubble t={t} a={97.8} b={99.5} x={240} y={250} w={450} h={150} text="তোমার *স্বপ্ন* কী?" tail={[550, 605]} fs={46} />
      <Bubble t={t} a={100.2} b={103.3} x={30} y={300} w={560} h={170} text="আমার *গাড়ি* হবে একদিন, ভাই।" tail={[160, 772]} fs={42} />
      <Show t={t} a={100.8} b={103.3} x={540} y={540} float={6}><Steering s={110} f={f} /></Show>
      <Bubble t={t} a={103.4} b={105.9} x={30} y={290} w={600} h={190} text="কিন্তু আমরা *গরিবের* কি আর হয়?" tail={[160, 772]} fs={42} />
      <Show t={t} a={104.0} b={105.9} x={560} y={540} float={6}><Question s={100} /></Show>
      <Bubble t={t} a={105.9} b={107.7} x={190} y={250} w={500} h={170} text="আমিও এই *দৌড়টাই* দৌড়েছি।" tail={[550, 605]} fs={42} />
      <Bubble t={t} a={107.7} b={111.5} x={40} y={200} w={640} h={250} text="শুধু স্বপ্ন দেখলে হয় না, রোজ একটু একটু করে *কাজ* করতে হয়।" tail={[550, 605]} fs={40} />
      <Wipe f={f} />
    </div>
  );
};
