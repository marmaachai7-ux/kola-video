import React from 'react';
import {Character, LOOKS} from '../Character';
import {Home} from '../Bg';
import {Card, NamePill, Show, Thought, ease, fontFamily, mk} from '../Ui';
import {Clock, Coin, Frame, Steering, Tiffin, TiffinProp} from '../Icons';
import {At, Wipe, useT} from './common';
import {W, H} from '../config';

export const Scene2: React.FC = () => {
  const {f, t} = useT(21.0);
  const night = t >= 35.0 ? 1 : 0;
  const imX = 40 + 170 * ease(t, 29.5, 31.5);
  const maX = 400 + 420 * ease(t, 29.5, 31);
  const minDeg = t < 26 ? (t - 23.9) * 900 : 0;
  const nightMood = t >= 35.0;
  const dim = night ? 0.25 : 0;

  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden'}}>
      <Home f={f} night={night} />
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, background: `rgba(5,5,30,${dim})`}} />

      <Show t={t} a={21.3} b={25.4} x={540} y={420}>
        <Frame s={190} />
      </Show>

      {/* ইমরান */}
      <At x={imX} y={640}>
        <Character
          look={LOOKS.imranTeen} width={300} f={f} seed={5}
          expr={nightMood ? (t >= 38.9 ? 'think' : 'sad') : t >= 29 ? 'tired' : t >= 23.9 ? 'tired' : 'neutral'}
          pose={t >= 38.9 ? 'think' : 'idle'}
          eyeX={nightMood && t < 38.9 ? -0.7 : 0}
          tremble={t >= 31.5 && t < 35 ? 0.9 : 0}
        />
      </At>

      {/* মা */}
      {t >= 25.8 && t < 31.2 && (
        <At x={maX} y={640}>
          <Character
            look={LOOKS.mother} width={300} f={f} seed={6}
            expr="happy" pose={t >= 26.3 ? 'give' : 'idle'}
            rightProp={t >= 26.3 ? <TiffinProp /> : undefined}
          />
        </At>
      )}
      <NamePill t={t} a={25.9} b={28.6} x={maX + 150} y={600} text="মা" color="#3e8a5a" />

      {/* কার্ড */}
      <Card t={t} a={23.9} b={26.2} x={360} y={330} w={320}>
        <Clock s={170} hr={150} min={minDeg} />
        <div style={{fontFamily, fontSize: 50, marginTop: 4}}>{mk('ভোর *৫:০০*')}</div>
      </Card>
      <Card t={t} a={26.5} b={29.2} x={360} y={330} w={330}>
        <Tiffin s={150} open />
        <div style={{fontFamily, fontSize: 42, marginTop: 4}}>২টি রুটি + ভাজি</div>
      </Card>

      {/* সারাদিনের খাটুনি */}
      {[[130, 400, 0], [330, 300, 0.4], [560, 420, 0.8]].map(([x, y, d], i) => (
        <Show key={i} t={t} a={31.2 + d} b={34.8} x={x} y={y} float={8}>
          <Coin s={100} />
        </Show>
      ))}
      <Show t={t} a={33.0} b={35.0} x={560} y={260}>
        <Clock s={150} hr={20} min={f * 14} />
      </Show>

      {/* রাতে ড্রাইভারের হাতের চিন্তা */}
      <Thought t={t} a={38.9} b={42.1} cx={470} cy={400} rx={140} ry={100} tail={[385, 640]}>
        <Steering s={130} f={f} />
      </Thought>
      <Wipe f={f} />
    </div>
  );
};
