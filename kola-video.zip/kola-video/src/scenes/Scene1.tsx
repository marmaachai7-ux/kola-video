import React from 'react';
import {Character, LOOKS, extraLook, mouthAt} from '../Character';
import {BusInterior} from '../Bg';
import {Bubble, NamePill, Show, ease} from '../Ui';
import {BagProp, LaughFace} from '../Icons';
import {At, Wipe, Zoom, useT} from './common';
import {W, H} from '../config';

export const Scene1: React.FC = () => {
  const {f, t} = useT(0);
  const laugh = t >= 9.5 && t < 13.4;
  const jSpeak = t >= 5.6 && t < 9.45;
  const bump = Math.sin(f / 3) * 2;
  const sad = t >= 11.1;
  const zoom = 1 + 0.1 * ease(t, 15, 21);

  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden', background: '#000'}}>
      <Zoom scale={zoom} ox={200} oy={850}>
        <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, transform: `translateY(${bump}px)`}}>
          <BusInterior f={f} layer="back" />

          {/* পেছনের যাত্রী */}
          <At x={30} y={505}>
            <Character look={extraLook(0)} crop="bust" width={210} f={f} seed={1} expr={laugh ? 'laugh' : 'neutral'} mouth={mouthAt(f, laugh)} pose="idle" />
          </At>
          <At x={250} y={522}>
            <Character look={extraLook(3)} crop="bust" width={180} f={f} seed={2} expr={laugh ? 'laugh' : 'neutral'} mouth={mouthAt(f + 5, laugh)} pose="idle" />
          </At>
          {/* কাকা জলিল */}
          <At x={350} y={500}>
            <Character
              look={LOOKS.jolil} crop="bust" width={330} f={f} seed={3}
              expr={laugh ? 'laugh' : jSpeak ? 'happy' : 'neutral'}
              mouth={jSpeak || laugh ? mouthAt(f, true) : 0}
              pose={jSpeak ? 'open' : 'idle'} tremble={laugh ? 2 : 0}
            />
          </At>

          <BusInterior f={f} layer="front" />

          {/* ইমরান */}
          <At x={10} y={720}>
            <Character
              look={LOOKS.imranTeen} crop="knee" width={380} f={f} seed={4}
              expr={sad ? 'sad' : 'neutral'} pose="hang" eyeX={sad ? -0.8 : 0}
              tremble={t >= 11.5 ? 1.4 : 0}
              leftProp={<BagProp />}
            />
          </At>
        </div>

        <NamePill t={t} a={2.0} b={5.3} x={520} y={468} text="কাকা জলিল" color="#a8553a" />
        <NamePill t={t} a={13.6} b={18} x={200} y={742} text="ইমরান · ১৬ বছর" color="#2f7dd1" />

        <Bubble
          t={t} a={5.5} b={11.1} x={50} y={175} w={620} h={210}
          text="দেখো দেখো, এই ছেলে নাকি একদিন বাসের *মালিক* হবে!"
          tail={[520, 525]} fs={42}
        />
        {[[110, 640, 0], [610, 470, 0.15], [340, 440, 0.3]].map(([x, y, d], i) => (
          <Show key={i} t={t} a={9.6 + d} b={13} x={x} y={y} rot={i * 8 - 8} float={6}>
            <LaughFace s={96} f={f} />
          </Show>
        ))}
      </Zoom>
      <Wipe f={f} color="#000" />
    </div>
  );
};
