import React from 'react';
import {fontFamily} from './Ui';

const INK = '#222222';
type IP = {s?: number; f?: number};
const Svg: React.FC<{s: number; children: React.ReactNode; vb?: string; h?: number}> = ({s, children, vb = '0 0 100 100', h}) => (
  <svg width={s} height={h ?? s} viewBox={vb} style={{overflow: 'visible'}}>{children}</svg>
);

export const Clock: React.FC<IP & {hr?: number; min?: number}> = ({s = 160, hr = 150, min = 0}) => (
  <Svg s={s}>
    <circle cx={50} cy={52} r={42} fill="#fff" stroke={INK} strokeWidth={4} />
    <rect x={30} y={4} width={40} height={10} rx={5} fill="#d8362f" stroke={INK} strokeWidth={3} />
    {Array.from({length: 12}).map((_, i) => (
      <line key={i} x1={50} y1={16} x2={50} y2={i % 3 === 0 ? 24 : 21} stroke={INK} strokeWidth={i % 3 === 0 ? 3.5 : 2} transform={`rotate(${i * 30} 50 52)`} />
    ))}
    <line x1={50} y1={52} x2={50} y2={30} stroke={INK} strokeWidth={5} strokeLinecap="round" transform={`rotate(${min} 50 52)`} />
    <line x1={50} y1={52} x2={50} y2={36} stroke="#d8362f" strokeWidth={6} strokeLinecap="round" transform={`rotate(${hr} 50 52)`} />
    <circle cx={50} cy={52} r={4} fill={INK} />
  </Svg>
);

export const Tiffin: React.FC<IP & {open?: boolean}> = ({s = 140, open = false}) => (
  <Svg s={s}>
    {open ? (
      <g>
        <ellipse cx={50} cy={62} rx={40} ry={14} fill="#b9bec6" stroke={INK} strokeWidth={4} />
        <ellipse cx={36} cy={52} rx={17} ry={8} fill="#e8b66a" stroke={INK} strokeWidth={3} />
        <ellipse cx={62} cy={50} rx={17} ry={8} fill="#e8b66a" stroke={INK} strokeWidth={3} />
        <path d="M44 62 Q56 52 74 60 Q70 70 52 70 Z" fill="#e8873a" stroke={INK} strokeWidth={3} />
        <rect x={10} y={62} width={80} height={24} rx={8} fill="#b9bec6" stroke={INK} strokeWidth={4} />
      </g>
    ) : (
      <g>
        <rect x={14} y={14} width={72} height={20} rx={8} fill="#c9ced6" stroke={INK} strokeWidth={4} />
        <rect x={14} y={36} width={72} height={24} rx={8} fill="#b9bec6" stroke={INK} strokeWidth={4} />
        <rect x={14} y={62} width={72} height={24} rx={8} fill="#c9ced6" stroke={INK} strokeWidth={4} />
        <path d="M30 14 Q50 -6 70 14" fill="none" stroke={INK} strokeWidth={4} />
      </g>
    )}
  </Svg>
);

export const Gear: React.FC<IP & {color?: string}> = ({s = 90, f = 0, color = '#9aa3ad'}) => (
  <Svg s={s}>
    <g transform={`rotate(${f * 3} 50 50)`}>
      {Array.from({length: 8}).map((_, i) => (
        <rect key={i} x={43} y={4} width={14} height={20} rx={3} fill={color} stroke={INK} strokeWidth={3} transform={`rotate(${i * 45} 50 50)`} />
      ))}
      <circle cx={50} cy={50} r={32} fill={color} stroke={INK} strokeWidth={4} />
      <circle cx={50} cy={50} r={12} fill="#f3eee2" stroke={INK} strokeWidth={4} />
    </g>
  </Svg>
);

export const Wrench: React.FC<IP & {rot?: number}> = ({s = 100, rot = 45}) => (
  <Svg s={s}>
    <g transform={`rotate(${rot} 50 50)`}>
      <rect x={42} y={30} width={16} height={62} rx={8} fill="#b9bec6" stroke={INK} strokeWidth={4} />
      <circle cx={50} cy={24} r={20} fill="#b9bec6" stroke={INK} strokeWidth={4} />
      <rect x={42} y={0} width={16} height={22} fill="#fff" opacity={0} />
      <path d="M42 2 L42 22 L58 22 L58 2 Z" fill="#f3eee2" stroke={INK} strokeWidth={3} />
    </g>
  </Svg>
);

export const BusSide: React.FC<IP & {w?: number; body?: string; smoke?: boolean; wheelSpin?: number}> = ({w = 420, f = 0, body = '#e0762e', smoke = false, wheelSpin = 6}) => (
  <Svg s={w} vb="0 0 420 220" h={w * 220 / 420}>
    {smoke && [0, 1, 2].map((i) => {
      const p = ((f + i * 14) % 42) / 42;
      return <circle key={i} cx={30 - p * 30} cy={80 - p * 70} r={14 + p * 18} fill="#8d8d8d" opacity={0.6 * (1 - p)} />;
    })}
    <rect x={30} y={30} width={370} height={140} rx={22} fill={body} stroke={INK} strokeWidth={5} />
    <rect x={30} y={112} width={370} height={22} fill="#f3d9a0" stroke={INK} strokeWidth={4} />
    {[0, 1, 2, 3, 4].map((i) => (
      <rect key={i} x={50 + i * 66} y={46} width={52} height={50} rx={8} fill="#bfe3f2" stroke={INK} strokeWidth={4} />
    ))}
    <rect x={346} y={46} width={44} height={74} rx={8} fill="#bfe3f2" stroke={INK} strokeWidth={4} />
    <rect x={394} y={120} width={16} height={22} rx={5} fill="#ffd23f" stroke={INK} strokeWidth={3} />
    {[110, 330].map((cx) => (
      <g key={cx}>
        <circle cx={cx} cy={174} r={30} fill="#2b2b2b" stroke={INK} strokeWidth={5} />
        <circle cx={cx} cy={174} r={14} fill="#c9ced6" stroke={INK} strokeWidth={3} />
        <g transform={`rotate(${f * wheelSpin} ${cx} 174)`}>
          <line x1={cx - 12} y1={174} x2={cx + 12} y2={174} stroke={INK} strokeWidth={3} />
        </g>
      </g>
    ))}
  </Svg>
);

export const Heart: React.FC<IP & {color?: string}> = ({s = 60, color = '#e0453a'}) => (
  <Svg s={s}>
    <path d="M50 88 C10 56 6 28 28 20 C40 16 48 24 50 32 C52 24 60 16 72 20 C94 28 90 56 50 88 Z" fill={color} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
  </Svg>
);

export const LaughFace: React.FC<IP> = ({s = 80, f = 0}) => (
  <Svg s={s}>
    <g transform={`rotate(${Math.sin(f * 0.8) * 8} 50 50)`}>
      <circle cx={50} cy={50} r={42} fill="#ffd23f" stroke={INK} strokeWidth={4} />
      <path d="M26 40 Q34 30 42 40 M58 40 Q66 30 74 40" fill="none" stroke={INK} strokeWidth={4.5} strokeLinecap="round" />
      <path d="M26 56 Q50 92 74 56 Z" fill="#7a2b2b" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
      <ellipse cx={50} cy={72} rx={12} ry={6} fill="#e8727a" />
    </g>
  </Svg>
);

export const Steering: React.FC<IP> = ({s = 100, f = 0}) => (
  <Svg s={s}>
    <g transform={`rotate(${Math.sin(f / 10) * 18} 50 50)`}>
      <circle cx={50} cy={50} r={40} fill="none" stroke="#3a3a3a" strokeWidth={10} />
      <circle cx={50} cy={50} r={40} fill="none" stroke={INK} strokeWidth={2} />
      <path d="M12 50 L38 52 M88 50 L62 52 M50 90 L50 62" stroke="#3a3a3a" strokeWidth={9} strokeLinecap="round" />
      <circle cx={50} cy={50} r={12} fill="#c9ced6" stroke={INK} strokeWidth={4} />
    </g>
  </Svg>
);

export const Check: React.FC<IP> = ({s = 70}) => (
  <Svg s={s}>
    <circle cx={50} cy={50} r={44} fill="#3fae5a" stroke={INK} strokeWidth={4} />
    <path d="M28 52 L44 68 L74 34" fill="none" stroke="#fff" strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

export const Cross: React.FC<IP> = ({s = 70}) => (
  <Svg s={s}>
    <circle cx={50} cy={50} r={44} fill="#d8362f" stroke={INK} strokeWidth={4} />
    <path d="M32 32 L68 68 M68 32 L32 68" fill="none" stroke="#fff" strokeWidth={10} strokeLinecap="round" />
  </Svg>
);

export const Question: React.FC<IP> = ({s = 70}) => (
  <Svg s={s}>
    <circle cx={50} cy={50} r={44} fill="#ffd23f" stroke={INK} strokeWidth={4} />
    <text x={50} y={72} textAnchor="middle" fontSize={64} fontWeight={700} fill={INK} fontFamily="Arial, sans-serif">?</text>
  </Svg>
);

export const Coin: React.FC<IP> = ({s = 70}) => (
  <Svg s={s}>
    <circle cx={50} cy={50} r={44} fill="#f2b92f" stroke={INK} strokeWidth={4} />
    <circle cx={50} cy={50} r={32} fill="none" stroke="#b9801a" strokeWidth={3} />
    <text x={50} y={66} textAnchor="middle" fontSize={46} fontWeight={700} fill={INK} fontFamily={fontFamily}>৳</text>
  </Svg>
);

export const Stairs: React.FC<IP & {steps?: number; shown?: number; w?: number}> = ({steps = 5, shown = 5, w = 420}) => {
  const sw = 80;
  const sh = 60;
  return (
    <svg width={w} height={w * 0.8} viewBox={`0 0 ${steps * sw + 20} ${steps * sh + 20}`} style={{overflow: 'visible'}}>
      {Array.from({length: steps}).map((_, i) => {
        const on = i < shown;
        return (
          <rect key={i} x={10 + i * sw} y={10 + (steps - 1 - i) * sh} width={sw} height={(i + 1) * sh} fill={on ? ['#f2b92f', '#e8873a', '#e0603a', '#c8453a', '#a63a5a'][i % 5] : 'transparent'} stroke={on ? INK : 'none'} strokeWidth={4} opacity={on ? 1 : 0} />
        );
      })}
    </svg>
  );
};

export const Bill: React.FC<IP & {lines?: number}> = ({s = 150}) => (
  <Svg s={s}>
    <path d="M22 8 L78 8 L78 92 L70 86 L62 92 L54 86 L46 92 L38 86 L30 92 L22 86 Z" fill="#fff" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
    {[26, 40, 54].map((y) => <line key={y} x1={32} y1={y} x2={68} y2={y} stroke="#9aa3ad" strokeWidth={4} strokeLinecap="round" />)}
    <text x={50} y={78} textAnchor="middle" fontSize={20} fontWeight={700} fill="#d8362f" fontFamily={fontFamily}>৳৳৳</text>
  </Svg>
);

export const Frame: React.FC<IP> = ({s = 150}) => (
  <Svg s={s}>
    <rect x={14} y={10} width={72} height={80} rx={6} fill="#7a4a2a" stroke={INK} strokeWidth={4} />
    <rect x={24} y={20} width={52} height={60} fill="#e8e1d0" stroke={INK} strokeWidth={3} />
    <circle cx={50} cy={42} r={12} fill="#a8693f" stroke={INK} strokeWidth={3} />
    <path d="M30 80 Q50 50 70 80 Z" fill="#6b6b6b" stroke={INK} strokeWidth={3} />
    <path d="M14 10 L36 10 L14 32 Z" fill="#111" />
  </Svg>
);

// ---- হাতের প্রপস (হাতের স্থানাঙ্কে আঁকা) ----
export const BagProp: React.FC = () => (
  <g transform="translate(-4 4)">
    <path d="M-6 -10 Q-30 30 -26 50" fill="none" stroke={INK} strokeWidth={4} />
    <rect x={-52} y={34} width={64} height={52} rx={10} fill="#8a5a3c" stroke={INK} strokeWidth={4} />
    <rect x={-52} y={34} width={64} height={18} rx={9} fill="#a8703f" stroke={INK} strokeWidth={4} />
    <circle cx={-20} cy={60} r={5} fill="#f2b92f" stroke={INK} strokeWidth={2} />
  </g>
);

export const TiffinProp: React.FC = () => (
  <g transform="translate(0 8)">
    <rect x={-26} y={0} width={52} height={14} rx={6} fill="#c9ced6" stroke={INK} strokeWidth={3} />
    <rect x={-26} y={15} width={52} height={16} rx={6} fill="#b9bec6" stroke={INK} strokeWidth={3} />
    <rect x={-26} y={32} width={52} height={14} rx={6} fill="#c9ced6" stroke={INK} strokeWidth={3} />
  </g>
);

export const WrenchProp: React.FC = () => (
  <g transform="translate(0 -4) rotate(-20)">
    <rect x={-6} y={-40} width={12} height={58} rx={6} fill="#b9bec6" stroke={INK} strokeWidth={3} />
    <circle cx={0} cy={-44} r={13} fill="#b9bec6" stroke={INK} strokeWidth={3} />
    <path d="M-5 -58 L-5 -44 L5 -44 L5 -58 Z" fill="#f3eee2" stroke={INK} strokeWidth={2} />
  </g>
);

export const PolyProp: React.FC = () => (
  <g transform="translate(0 6)">
    <path d="M-4 0 Q-34 10 -26 42 Q-10 58 14 46 Q26 20 6 0 Z" fill="#e9eef5" stroke={INK} strokeWidth={3} opacity={0.95} />
    <circle cx={-8} cy={28} r={7} fill="#e8873a" />
    <circle cx={6} cy={34} r={6} fill="#d8b24a" />
  </g>
);

export const HeavyBagProp: React.FC = () => (
  <g transform="translate(0 6)">
    <rect x={-44} y={-6} width={88} height={64} rx={14} fill="#3a6f9a" stroke={INK} strokeWidth={4} />
    <rect x={-44} y={-6} width={88} height={20} rx={10} fill="#4a85b8" stroke={INK} strokeWidth={4} />
    <circle cx={0} cy={34} r={7} fill="#f2b92f" stroke={INK} strokeWidth={2} />
  </g>
);
