import React from 'react';

const INK = '#222222';
const SW = 3;

export type Expr =
  | 'neutral' | 'happy' | 'laugh' | 'sad' | 'cry' | 'angry'
  | 'surprised' | 'worried' | 'think' | 'shy' | 'determined' | 'tired';

export type Arm = [number, number]; // [কাঁধের কোণ, কনুইয়ের কোণ]
export type Pose = {l: Arm; r: Arm};

// বাম হাত = স্ক্রিনের বাম। ধনাত্মক কোণ = ঘড়ির কাঁটার দিকে।
export const POSES: Record<string, Pose> = {
  idle: {l: [5, 8], r: [-5, -8]},
  hold: {l: [-12, -95], r: [12, 95]},
  hang: {l: [5, 8], r: [-172, 0]},
  point: {l: [5, 8], r: [-95, -8]},
  think: {l: [5, 8], r: [45, 130]},
  wave: {l: [5, 8], r: [-150, -25]},
  open: {l: [28, -35], r: [-28, 35]},
  work: {l: [-40, -70], r: [40, 70]},
  carry: {l: [-30, -45], r: [30, 45]},
  give: {l: [5, 8], r: [-70, -10]},
  cheer: {l: [150, 20], r: [-150, -20]},
  chest: {l: [-25, -120], r: [25, 120]},
  bagL: {l: [10, -22], r: [-5, -8]},
};

export interface Look {
  skin: string;
  hair: string;
  hairStyle: 'short' | 'messy' | 'bald' | 'scarf' | 'ghomta' | 'side';
  shirt: string;
  shirt2?: string;
  pants: string;
  shoes?: string;
  outfit: 'shirt' | 'panjabi' | 'tee' | 'overall' | 'saree' | 'suit';
  beard?: 'none' | 'stubble' | 'full' | 'mustache';
  glasses?: boolean;
  kid?: boolean;
  sleeves?: 'short' | 'long';
  lungi?: boolean;
  watch?: boolean;
  grease?: boolean;
}

export interface CharacterProps {
  look: Look;
  f?: number; // ফ্রেম (ভাসমান/ব্লিংকের জন্য)
  expr?: Expr;
  mouth?: 0 | 1 | 2; // 0 বন্ধ, 1 ছোট খোলা, 2 বড় খোলা
  pose?: string | Pose;
  pose2?: string | Pose;
  mix?: number; // pose -> pose2
  eyeX?: number; // -1..1
  tremble?: number; // px
  walk?: number; // হাঁটা/দৌড়ের কোণ (deg)
  float?: boolean;
  seed?: number;
  crop?: 'full' | 'knee' | 'bust';
  width?: number;
  flip?: boolean;
  leftProp?: React.ReactNode;
  rightProp?: React.ReactNode;
  style?: React.CSSProperties;
}

const CROPS = {
  full: {y: 0, h: 560},
  knee: {y: 0, h: 430},
  bust: {y: 30, h: 300},
};

const getPose = (p: string | Pose | undefined): Pose =>
  typeof p === 'string' ? POSES[p] || POSES.idle : p || POSES.idle;
const lerp = (a: number, b: number, m: number) => a + (b - a) * m;

const BROW: Record<Expr, {dy: number; a: number; rr?: number}> = {
  neutral: {dy: 0, a: 0},
  happy: {dy: -6, a: -6},
  laugh: {dy: -8, a: -8},
  sad: {dy: -2, a: -18},
  cry: {dy: -2, a: -22},
  angry: {dy: 4, a: 20},
  surprised: {dy: -14, a: -4},
  worried: {dy: -2, a: -14},
  think: {dy: -2, a: 6, rr: -8},
  shy: {dy: 0, a: -8},
  determined: {dy: 2, a: 10},
  tired: {dy: 3, a: -6},
};

const Mouth: React.FC<{expr: Expr; open: 0 | 1 | 2; skin: string; beard: boolean; lip: string}> = ({expr, open, skin, beard, lip}) => {
  const cx = 150;
  const cy = 156;
  let shape: React.ReactNode;
  if (open > 0) {
    const rx = open === 1 ? 11 : 16;
    const ry = open === 1 ? 7 : 14;
    shape = (
      <g>
        <ellipse cx={cx} cy={cy + 2} rx={rx} ry={ry} fill="#7a2b2b" stroke={INK} strokeWidth={SW} />
        {open === 2 && <ellipse cx={cx} cy={cy + ry - 3} rx={rx * 0.6} ry={5} fill="#e8727a" />}
      </g>
    );
  } else {
    const p: Record<Expr, string> = {
      neutral: 'M136 156 L164 156',
      happy: 'M130 150 Q150 172 170 150',
      laugh: 'M128 148 Q150 184 172 148 Z',
      sad: 'M132 164 Q150 148 168 164',
      cry: 'M132 166 Q150 146 168 166',
      angry: 'M134 162 Q150 150 166 162',
      surprised: 'M144 150 Q150 148 156 150 Q160 166 150 168 Q140 166 144 150',
      worried: 'M134 160 Q142 152 150 160 Q158 168 166 158',
      think: 'M138 158 L162 152',
      shy: 'M138 154 Q152 166 164 152',
      determined: 'M136 158 Q150 160 164 156',
      tired: 'M136 162 Q150 156 164 162',
    };
    const fill = expr === 'laugh' || expr === 'surprised' ? '#7a2b2b' : 'none';
    shape = <path d={p[expr]} fill={fill} stroke={INK} strokeWidth={SW + 0.5} strokeLinecap="round" strokeLinejoin="round" />;
  }
  return (
    <g>
      {beard && <ellipse cx={cx} cy={cy} rx={22} ry={12} fill={lip} />}
      {shape}
    </g>
  );
};

export const Character: React.FC<CharacterProps> = ({
  look, f = 0, expr = 'neutral', mouth = 0, pose = 'idle', pose2, mix = 0, eyeX = 0,
  tremble = 0, walk = 0, float = true, seed = 0, crop = 'full', width = 300, flip = false,
  leftProp, rightProp, style,
}) => {
  const c = CROPS[crop];
  const k = width / 300;
  const A = getPose(pose);
  const B = pose2 ? getPose(pose2) : A;
  const m = pose2 ? mix : 0;
  const lerpArm = (a: Arm, b: Arm): Arm => [lerp(a[0], b[0], m), lerp(a[1], b[1], m)];
  const sw = walk ? Math.sin((f + seed * 7) * 0.45) * walk : 0;
  const L = lerpArm(A.l, B.l);
  const R = lerpArm(A.r, B.r);
  const lArm: Arm = [L[0] + sw, L[1]];
  const rArm: Arm = [R[0] + sw, R[1]];

  const bob = float ? Math.sin((f + seed * 13) / 14) * 4 : 0;
  const trx = tremble ? Math.sin((f + seed) * 2.7) * tremble : 0;
  const try_ = tremble ? Math.cos((f + seed) * 3.1) * tremble * 0.6 : 0;
  const blink = (f + seed * 23) % 105 < 4;
  const sleepy = expr === 'tired';

  const s = look;
  const long = s.sleeves === 'long' || s.outfit === 'panjabi' || s.outfit === 'suit' || s.outfit === 'saree';
  const sleeveCol = s.outfit === 'overall' ? s.shirt2 || '#e8e1d0' : s.shirt;
  const lip = s.hair === '#1a1a1a' ? '#3a3a3a' : s.hair;
  const bw = BROW[expr];
  const skinDark = shade(s.skin, -18);
  const hasBeard = s.beard === 'full';

  const arm = (side: 'l' | 'r') => {
    const a = side === 'l' ? lArm : rArm;
    const x = side === 'l' ? 92 : 208;
    const prop = side === 'l' ? leftProp : rightProp;
    const armSkin = s.skin;
    return (
      <g transform={`translate(${x} 218) rotate(${a[0]})`}>
        <rect x={-16} y={-8} width={32} height={78} rx={16} fill={long ? sleeveCol : armSkin} stroke={INK} strokeWidth={SW} />
        {!long && <rect x={-17} y={-9} width={34} height={44} rx={15} fill={sleeveCol} stroke={INK} strokeWidth={SW} />}
        <g transform={`translate(0 66) rotate(${a[1]})`}>
          <rect x={-14} y={-8} width={28} height={66} rx={14} fill={long ? sleeveCol : armSkin} stroke={INK} strokeWidth={SW} />
          {long && <rect x={-15} y={42} width={30} height={10} rx={4} fill={shade(sleeveCol, -20)} stroke={INK} strokeWidth={2} />}
          {s.grease && <path d="M-8 20 L6 26 M-6 34 L8 36" stroke="#2b2b2b" strokeWidth={5} strokeLinecap="round" opacity={0.55} />}
          {s.watch && side === 'l' && <rect x={-15} y={36} width={30} height={9} rx={3} fill="#3d3d3d" stroke={INK} strokeWidth={2} />}
          <circle cx={0} cy={62} r={16} fill={armSkin} stroke={INK} strokeWidth={SW} />
          {prop && <g transform="translate(0 62)">{prop}</g>}
        </g>
      </g>
    );
  };

  const leg = (x: number, dir: number) => (
    <g transform={`translate(${x} 372) rotate(${sw * dir * 0.9})`}>
      <rect x={-21} y={0} width={42} height={140} rx={18} fill={s.pants} stroke={INK} strokeWidth={SW} />
      <ellipse cx={dir * -3} cy={148} rx={29} ry={14} fill={s.shoes || '#3a3330'} stroke={INK} strokeWidth={SW} />
    </g>
  );

  const bodyLen = s.outfit === 'panjabi' ? 450 : s.outfit === 'saree' ? 505 : 392;
  const bodyPath = `M92 214 Q92 190 122 190 L178 190 Q208 190 208 214 L214 ${bodyLen - 12} Q214 ${bodyLen} 200 ${bodyLen} L100 ${bodyLen} Q86 ${bodyLen} 86 ${bodyLen - 12} Z`;

  const eyeY = 120;
  const eyeR = sleepy ? 0.45 : 1;

  return (
    <svg
      viewBox={`0 ${c.y} 300 ${c.h}`}
      width={width}
      height={c.h * k}
      style={{overflow: 'visible', transform: flip ? 'scaleX(-1)' : undefined, ...style}}
    >
      <g transform={`translate(${trx} ${bob + try_})`}>
        {/* পা */}
        {s.lungi ? (
          <g>
            <ellipse cx={122} cy={520} rx={28} ry={13} fill={s.shoes || '#3a3330'} stroke={INK} strokeWidth={SW} />
            <ellipse cx={178} cy={520} rx={28} ry={13} fill={s.shoes || '#3a3330'} stroke={INK} strokeWidth={SW} />
            <path d="M92 370 L208 370 L214 500 L86 500 Z" fill={s.pants} stroke={INK} strokeWidth={SW} />
            {[0, 1, 2, 3].map((i) => (
              <path key={i} d={`M${100 + i * 28} 372 L${96 + i * 30} 498`} stroke="#fff" strokeWidth={3} opacity={0.5} />
            ))}
            {[0, 1, 2, 3].map((i) => (
              <path key={'h' + i} d={`M90 ${400 + i * 28} L210 ${400 + i * 28}`} stroke="#fff" strokeWidth={3} opacity={0.5} />
            ))}
          </g>
        ) : s.outfit === 'saree' ? null : (
          <g>
            {leg(122, 1)}
            {leg(178, -1)}
          </g>
        )}

        {/* শরীর */}
        <path d={bodyPath} fill={s.shirt} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
        {s.outfit === 'saree' && (
          <g>
            <path d="M86 480 L214 480 L220 505 L80 505 Z" fill={shade(s.shirt, -25)} stroke={INK} strokeWidth={2} />
            <path d="M92 214 L208 330 L208 214 Z" fill={s.shirt2 || '#f4d27a'} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <ellipse cx={122} cy={522} rx={28} ry={13} fill="#3a3330" stroke={INK} strokeWidth={SW} />
            <ellipse cx={178} cy={522} rx={28} ry={13} fill="#3a3330" stroke={INK} strokeWidth={SW} />
          </g>
        )}
        {s.outfit === 'shirt' && (
          <g>
            <path d="M150 196 L150 388" stroke={INK} strokeWidth={2.5} />
            {[236, 280, 324].map((y) => <circle key={y} cx={153} cy={y} r={3.5} fill="#fff" stroke={INK} strokeWidth={1.5} />)}
            <path d="M128 190 L150 214 L172 190 Z" fill="#fff" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <rect x={104} y={262} width={32} height={34} rx={4} fill="none" stroke={INK} strokeWidth={2} opacity={0.5} />
            <path d="M100 340 Q150 352 200 340" fill="none" stroke={INK} strokeWidth={2} opacity={0.25} />
          </g>
        )}
        {s.outfit === 'panjabi' && (
          <g>
            <path d="M150 192 L150 300" stroke={INK} strokeWidth={2.5} />
            {[222, 254, 286].map((y) => <circle key={y} cx={150} cy={y} r={3.5} fill="#fff" stroke={INK} strokeWidth={1.5} />)}
            <path d="M126 191 Q150 208 174 191" fill="none" stroke={INK} strokeWidth={SW} />
            <path d="M100 440 L100 450 M200 440 L200 450" stroke={INK} strokeWidth={2} />
            <path d="M96 330 Q150 345 204 330" fill="none" stroke={INK} strokeWidth={2} opacity={0.25} />
          </g>
        )}
        {s.outfit === 'tee' && <path d="M126 191 Q150 214 174 191" fill={shade(s.skin, 0)} stroke={INK} strokeWidth={SW} />}
        {s.outfit === 'overall' && (
          <g>
            <path d="M126 191 Q150 214 174 191" fill={s.skin} stroke={INK} strokeWidth={SW} />
            <rect x={120} y={270} width={60} height={44} rx={6} fill={shade(s.shirt, -14)} stroke={INK} strokeWidth={2} />
            <path d="M150 316 L150 392" stroke={INK} strokeWidth={2.5} />
            <path d="M96 360 L120 372 M204 360 L180 372" stroke="#2b2b2b" strokeWidth={9} opacity={0.4} strokeLinecap="round" />
          </g>
        )}
        {s.outfit === 'suit' && (
          <g>
            <path d="M128 190 L150 216 L172 190 Z" fill="#fff" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <path d="M144 214 L156 214 L160 300 L150 312 L140 300 Z" fill="#b33a3a" stroke={INK} strokeWidth={2.5} strokeLinejoin="round" />
            <path d="M92 230 L146 300 L100 392 M208 230 L154 300 L200 392" fill="none" stroke={INK} strokeWidth={2.5} opacity={0.5} />
          </g>
        )}
        {s.grease && <path d="M110 330 L130 340 M170 300 L186 312" stroke="#222" strokeWidth={6} opacity={0.4} strokeLinecap="round" />}

        {/* হাত (পেছনে ডান, সামনে বাম) */}
        {arm('r')}
        {arm('l')}

        {/* ঘাড় */}
        <rect x={134} y={168} width={32} height={34} rx={8} fill={skinDark} stroke={INK} strokeWidth={SW} />

        {/* মাথা */}
        <circle cx={90} cy={124} r={12} fill={s.skin} stroke={INK} strokeWidth={SW} />
        <circle cx={210} cy={124} r={12} fill={s.skin} stroke={INK} strokeWidth={SW} />
        {s.hairStyle === 'ghomta' && (
          <path d="M150 34 C70 34 66 120 70 170 C74 210 96 232 110 244 L190 244 C204 232 226 210 230 170 C234 120 230 34 150 34 Z" fill={s.shirt} stroke={INK} strokeWidth={SW} />
        )}
        <ellipse cx={150} cy={118} rx={s.kid ? 64 : 60} ry={s.kid ? 68 : 66} fill={s.skin} stroke={INK} strokeWidth={SW} />

        {/* চুল */}
        {s.hairStyle === 'short' && (
          <path d="M90 108 C84 48 128 36 150 36 C176 36 218 50 210 108 C198 84 174 76 150 78 C126 76 102 84 90 108 Z" fill={s.hair} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
        )}
        {s.hairStyle === 'messy' && (
          <path d="M88 112 C80 60 100 40 122 44 L130 28 L142 42 L156 26 L166 42 L184 32 L188 50 C214 56 218 86 212 112 C198 86 176 80 150 82 C124 80 102 88 88 112 Z" fill={s.hair} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
        )}
        {s.hairStyle === 'side' && (
          <path d="M90 110 C82 50 126 34 156 38 C190 40 218 60 210 112 C204 86 186 70 150 76 C124 82 104 90 90 110 Z" fill={s.hair} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
        )}
        {s.hairStyle === 'bald' && (
          <g>
            <path d="M92 122 C84 100 88 84 96 80 C94 96 96 110 100 124 Z" fill={s.hair} stroke={INK} strokeWidth={SW} />
            <path d="M208 122 C216 100 212 84 204 80 C206 96 204 110 200 124 Z" fill={s.hair} stroke={INK} strokeWidth={SW} />
          </g>
        )}
        {s.hairStyle === 'scarf' && (
          <g>
            <path d="M88 104 C82 46 122 34 150 34 C180 34 220 48 212 104 C196 84 172 74 150 76 C126 74 102 84 88 104 Z" fill="#c8453a" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <path d="M96 92 L204 92 M92 78 L208 78" stroke="#fff" strokeWidth={4} opacity={0.7} />
            <path d="M206 98 L236 120 L222 132 L204 108 Z" fill="#c8453a" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
          </g>
        )}

        {/* গাল */}
        <circle cx={108} cy={146} r={11} fill="#e86a5a" opacity={0.28} />
        <circle cx={192} cy={146} r={11} fill="#e86a5a" opacity={0.28} />

        {/* চোখ */}
        {[125, 175].map((ex, i) => (
          <g key={ex}>
            <g transform={`translate(${ex} ${eyeY}) scale(1 ${blink ? 0.08 : eyeR})`}>
              <ellipse cx={0} cy={0} rx={12} ry={expr === 'surprised' ? 15 : 12} fill="#fff" stroke={INK} strokeWidth={2.5} />
              <circle cx={eyeX * 4} cy={1} r={expr === 'surprised' ? 4.5 : 6} fill={INK} />
              <circle cx={eyeX * 4 + 2} cy={-2} r={1.8} fill="#fff" />
            </g>
            {sleepy && !blink && <path d={`M${ex - 13} ${eyeY - 2} Q${ex} ${eyeY - 8} ${ex + 13} ${eyeY - 2} L${ex + 13} ${eyeY - 14} L${ex - 13} ${eyeY - 14} Z`} fill={s.skin} stroke={INK} strokeWidth={2} />}
            <path
              d={`M${ex - 17} 0 L${ex + 17} 0`}
              transform={`translate(0 ${96 + bw.dy + (i === 1 && bw.rr ? bw.rr : 0)}) rotate(${i === 0 ? bw.a : -bw.a} ${ex} 0)`}
              stroke={s.hair === '#c9c9c9' ? '#8a8a8a' : INK}
              strokeWidth={6}
              strokeLinecap="round"
            />
            {s.glasses && <circle cx={ex} cy={eyeY} r={19} fill="none" stroke={INK} strokeWidth={3} />}
          </g>
        ))}
        {s.glasses && <path d="M144 120 L156 120" stroke={INK} strokeWidth={3} />}

        {/* নাক */}
        <path d="M146 134 Q150 146 158 142" fill="none" stroke={shade(s.skin, -40)} strokeWidth={3} strokeLinecap="round" />

        {/* দাড়ি, গোঁফ, মুখ */}
        {hasBeard && (
          <path d="M92 122 C92 196 208 196 208 122 C202 164 176 176 150 176 C124 176 98 164 92 122 Z" fill={lip} stroke={INK} strokeWidth={SW} />
        )}
        {s.beard === 'stubble' && (
          <path d="M94 130 C98 186 202 186 206 130 C196 168 176 176 150 176 C124 176 104 168 94 130 Z" fill={s.hair} opacity={0.3} />
        )}
        <Mouth expr={expr} open={mouth} skin={s.skin} beard={hasBeard} lip={'#b87a62'} />
        {(s.beard === 'mustache' || hasBeard) && (
          <path d="M128 148 Q140 140 150 146 Q160 140 172 148 Q160 152 150 150 Q140 152 128 148 Z" fill={s.hair} stroke={INK} strokeWidth={2} />
        )}

        {/* কান্না ও ঘাম */}
        {(expr === 'cry' || expr === 'sad') && (
          <ellipse cx={118} cy={140 + ((f * 2) % 28)} rx={4.5} ry={7} fill="#6ec1f0" stroke={INK} strokeWidth={1.5} opacity={expr === 'cry' ? 1 : 0.8} />
        )}
        {expr === 'cry' && <ellipse cx={182} cy={140 + ((f * 2 + 14) % 28)} rx={4.5} ry={7} fill="#6ec1f0" stroke={INK} strokeWidth={1.5} />}
        {expr === 'worried' && <path d="M196 70 Q202 84 196 90 Q188 84 196 70 Z" fill="#6ec1f0" stroke={INK} strokeWidth={1.5} />}
      </g>
    </svg>
  );
};

function shade(hex: string, amt: number): string {
  const h = hex.replace('#', '');
  if (h.length !== 6) return hex;
  const n = parseInt(h, 16);
  const cl = (v: number) => Math.max(0, Math.min(255, v));
  const r = cl((n >> 16) + amt);
  const g = cl(((n >> 8) & 255) + amt);
  const b = cl((n & 255) + amt);
  return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
}

// ---- ক্যারেক্টার লুক ----
export const LOOKS: Record<string, Look> = {
  imranTeen: {skin: '#b97a50', hair: '#1a1a1a', hairStyle: 'messy', shirt: '#e0a92e', pants: '#cdbf9a', outfit: 'shirt', sleeves: 'short', watch: true},
  imranOwner: {skin: '#b97a50', hair: '#1a1a1a', hairStyle: 'short', shirt: '#2f5d8a', pants: '#2b2f3a', outfit: 'shirt', sleeves: 'long', beard: 'stubble', watch: true},
  imranGarage: {skin: '#b97a50', hair: '#1a1a1a', hairStyle: 'short', shirt: '#2f5d8a', shirt2: '#e8e1d0', pants: '#2f5d8a', outfit: 'overall', sleeves: 'short', grease: true, beard: 'stubble'},
  jolil: {skin: '#a8693f', hair: '#c9c9c9', hairStyle: 'bald', shirt: '#8a5a3c', pants: '#3f6f9a', outfit: 'panjabi', lungi: true, beard: 'mustache'},
  rakib: {skin: '#b0724a', hair: '#1a1a1a', hairStyle: 'messy', shirt: '#e9e5da', pants: '#6b6b6b', outfit: 'tee', sleeves: 'short', kid: true},
  trader: {skin: '#b57a54', hair: '#1a1a1a', hairStyle: 'side', shirt: '#8c929c', pants: '#2b2b33', outfit: 'suit', glasses: true},
  mother: {skin: '#b57a54', hair: '#1a1a1a', hairStyle: 'ghomta', shirt: '#3e8a5a', shirt2: '#f4d27a', pants: '#3e8a5a', outfit: 'saree', sleeves: 'long'},
  ostad: {skin: '#a0653f', hair: '#c9c9c9', hairStyle: 'scarf', shirt: '#2f5d8a', pants: '#2f5d8a', outfit: 'overall', shirt2: '#d6d0c0', sleeves: 'long', beard: 'full', grease: true},
};

const EXTRA_SKINS = ['#b97a50', '#a8693f', '#c58a5e', '#9b5f3a'];
const EXTRA_SHIRTS = ['#c0453a', '#3a7a5a', '#4a6fa5', '#d28a2e', '#7a4a8a', '#5a8a8a'];
export const extraLook = (i: number): Look => ({
  skin: EXTRA_SKINS[i % EXTRA_SKINS.length],
  hair: i % 3 === 2 ? '#c9c9c9' : '#1a1a1a',
  hairStyle: (['short', 'side', 'messy', 'bald'] as const)[i % 4],
  shirt: EXTRA_SHIRTS[i % EXTRA_SHIRTS.length],
  pants: '#3a3f4a',
  outfit: i % 2 ? 'shirt' : 'tee',
  sleeves: 'short',
  beard: i % 5 === 3 ? 'mustache' : 'none',
});

export const mouthAt = (f: number, speaking: boolean): 0 | 1 | 2 => {
  if (!speaking) return 0;
  const seq: (0 | 1 | 2)[] = [1, 2, 1, 2, 0, 1, 2, 1];
  return seq[Math.floor(f / 4) % seq.length];
};
