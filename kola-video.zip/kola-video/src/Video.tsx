import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {FPS, SCENES, SHAKES, sec} from './config';
import {Caption} from './Ui';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';
import {Scene6} from './scenes/Scene6';

const COMPONENTS = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6];

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  let dx = 0;
  let dy = 0;
  for (const [a, b, amp] of SHAKES) {
    if (t >= a && t <= b) {
      dx = Math.sin(frame * 2.9) * amp;
      dy = Math.cos(frame * 3.7) * amp * 0.7;
    }
  }
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <AbsoluteFill style={{transform: `translate(${dx}px, ${dy}px) scale(1.02)`}}>
        {SCENES.map((s, i) => {
          const C = COMPONENTS[i];
          return (
            <Sequence key={s.id} from={sec(s.start)} durationInFrames={sec(s.end) - sec(s.start)}>
              <C />
            </Sequence>
          );
        })}
      </AbsoluteFill>
      <Caption t={t} />
      <Audio src={staticFile('voice.mp3')} />
    </AbsoluteFill>
  );
};
