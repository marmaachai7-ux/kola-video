import React from 'react';
import {spring} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {CAPTIONS} from './captions';
import {FPS, KEYWORDS, QUIET, W, H} from './config';

export const {fontFamily} = loadFont('normal', {weights: ['500', '700'], subsets: ['bengali', 'latin']});

export const INK = '#222222';
export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const vis = (t: number, a: number, b: number, fade = 0.3) =>
  clamp01(Math.min((t - a) / fade, (b - t) / fade));
export const ease = (t: number, a: number, b: number) => {
  const x = clamp01((t - a) / (b - a));
  return x * x * (3 - 2 * x);
};
export const popS = (t: number, a: number) => {
  const fr = (t - a) * FPS;
  if (fr < 0) return 0;
  return spring({frame: fr, fps: FPS, config: {damping: 11, stiffness: 150}});
};
const outS = (t: number, b: number) => clamp01((b - t) / 0.2);

// কেন্দ্র-অ্যাঙ্কর করা পপ-আপ
export const Show: React.FC<{
  t: number; a: number; b: number; x: number; y: number; rot?: number; children: React.ReactNode; float?: number;
}> = ({t, a, b, x, y, rot = 0, children, float = 0}) => {
  if (t < a || t > b) return null;
  const s = popS(t, a) * outS(t, b);
  const fy = float ? Math.sin(t * 3) * float : 0;
  return (
    <div style={{position: 'absolute', left: x, top: y + fy, transform: `translate(-50%,-50%) scale(${s}) rotate(${rot}deg)`}}>
      {children}
    </div>
  );
};

const renderMarked = (text: string, hl = '#d8362f') =>
  text.split('*').map((p, i) => (i % 2 ? <span key={i} style={{color: hl}}>{p}</span> : <span key={i}>{p}</span>));

export const mk = renderMarked;

// স্পিচ বাবল (লেজ সহ)
export const Bubble: React.FC<{
  t: number; a: number; b: number; x: number; y: number; w: number; h: number;
  text: string; tail: [number, number]; fs?: number; fill?: string;
}> = ({t, a, b, x, y, w, h, text, tail, fs = 42, fill = '#ffffff'}) => {
  if (t < a || t > b) return null;
  const s = popS(t, a) * outS(t, b);
  const bx = Math.max(x + 60, Math.min(x + w - 60, tail[0]));
  const down = tail[1] > y + h / 2;
  const by = down ? y + h : y;
  const dir = down ? -2 : 2;
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, transform: `scale(${s})`, transformOrigin: `${tail[0]}px ${tail[1]}px`}}>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <polygon points={`${bx - 22},${by + dir} ${bx + 22},${by + dir} ${tail[0]},${tail[1]}`} fill={fill} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        <rect x={x} y={y} width={w} height={h} rx={34} fill={fill} stroke={INK} strokeWidth={4} />
        <rect x={bx - 19} y={down ? by - 5 : by - 1} width={38} height={6} fill={fill} />
      </svg>
      <div style={{position: 'absolute', left: x, top: y, width: w, height: h, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '10px 26px', boxSizing: 'border-box', fontFamily, fontWeight: 700, fontSize: fs, lineHeight: 1.25, color: INK}}>
        <div>{renderMarked(text)}</div>
      </div>
    </div>
  );
};

// থট বাবল (ভেতরে আইকন)
export const Thought: React.FC<{
  t: number; a: number; b: number; cx: number; cy: number; rx: number; ry: number; tail: [number, number]; children?: React.ReactNode;
}> = ({t, a, b, cx, cy, rx, ry, tail, children}) => {
  if (t < a || t > b) return null;
  const s = popS(t, a) * outS(t, b);
  const dx = tail[0] - cx;
  const dy = tail[1] - cy;
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, transform: `scale(${s})`, transformOrigin: `${tail[0]}px ${tail[1]}px`}}>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <circle cx={cx + dx * 0.62} cy={cy + dy * 0.7} r={14} fill="#fff" stroke={INK} strokeWidth={4} />
        <circle cx={cx + dx * 0.86} cy={cy + dy * 0.88} r={8} fill="#fff" stroke={INK} strokeWidth={4} />
        <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="#fff" stroke={INK} strokeWidth={4} />
      </svg>
      <div style={{position: 'absolute', left: cx - rx, top: cy - ry, width: rx * 2, height: ry * 2, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{children}</div>
    </div>
  );
};

export const NamePill: React.FC<{t: number; a: number; b: number; x: number; y: number; text: string; color?: string}> = ({t, a, b, x, y, text, color = '#2f7dd1'}) => (
  <Show t={t} a={a} b={b} x={x} y={y}>
    <div style={{background: color, color: '#fff', border: `3px solid ${INK}`, borderRadius: 40, padding: '6px 26px', fontFamily, fontWeight: 700, fontSize: 34, whiteSpace: 'nowrap', boxShadow: '0 5px 0 rgba(0,0,0,.25)'}}>{text}</div>
  </Show>
);

export const Card: React.FC<{
  t: number; a: number; b: number; x: number; y: number; w: number; rot?: number; bg?: string; children: React.ReactNode; pin?: boolean;
}> = ({t, a, b, x, y, w, rot = 0, bg = '#fff8e6', children, pin = true}) => (
  <Show t={t} a={a} b={b} x={x} y={y} rot={rot}>
    <div style={{width: w, background: bg, border: `4px solid ${INK}`, borderRadius: 24, padding: '22px 20px', boxSizing: 'border-box', boxShadow: '0 10px 0 rgba(0,0,0,.28)', textAlign: 'center', fontFamily, fontWeight: 700, color: INK, position: 'relative'}}>
      {pin && <div style={{position: 'absolute', top: -14, left: '50%', marginLeft: -14, width: 28, height: 28, borderRadius: 14, background: '#d8362f', border: `3px solid ${INK}`}} />}
      {children}
    </div>
  </Show>
);

export const Stamp: React.FC<{t: number; a: number; b: number; x: number; y: number; text: string; color?: string; rot?: number; fs?: number}> = ({t, a, b, x, y, text, color = '#d8362f', rot = -8, fs = 64}) => (
  <Show t={t} a={a} b={b} x={x} y={y} rot={rot}>
    <div style={{border: `7px solid ${color}`, color, borderRadius: 18, padding: '6px 26px', fontFamily, fontWeight: 700, fontSize: fs, whiteSpace: 'nowrap', background: 'rgba(255,255,255,.88)', letterSpacing: 2}}>{text}</div>
  </Show>
);

// নিচের ভাসমান ক্যাপশন — কলআউট/কার্ড থাকলে দেখাবে না
export const Caption: React.FC<{t: number}> = ({t}) => {
  if (QUIET.some(([a, b]) => t >= a && t <= b)) return null;
  const c = CAPTIONS.find((x) => t >= x.s && t < x.e);
  if (!c) return null;
  const lt = t - c.s;
  const s = spring({frame: lt * FPS, fps: FPS, config: {damping: 14, stiffness: 170}});
  const words = c.text.split(' ');
  return (
    <div style={{position: 'absolute', left: 0, width: W, bottom: 170, display: 'flex', justifyContent: 'center', opacity: clamp01(lt / 0.12), transform: `translateY(${(1 - s) * 30}px)`}}>
      <div style={{background: 'rgba(0,0,0,.74)', borderRadius: 18, padding: '8px 26px 12px', fontFamily, fontWeight: 700, fontSize: 40, whiteSpace: 'nowrap', color: '#fff'}}>
        {words.map((w, i) => {
          const clean = w.replace(/[,।?!]/g, '');
          const hot = KEYWORDS.some((k) => clean.startsWith(k));
          return <span key={i} style={{color: hot ? '#FFD23F' : '#fff'}}>{w}{i < words.length - 1 ? ' ' : ''}</span>;
        })}
      </div>
    </div>
  );
};
