import React from 'react';
import {W, H} from './config';
import {clamp01} from './Ui';

const INK = '#222222';
const Full: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>{children}</svg>
);

const Tree: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-6} y={0} width={12} height={40} fill="#6b4a2a" />
    <circle cx={0} cy={-6} r={30} fill="#4fa05a" />
    <circle cx={-18} cy={8} r={20} fill="#3f8a4c" />
    <circle cx={18} cy={8} r={20} fill="#3f8a4c" />
  </g>
);

// বাসের ভেতরের দৃশ্য — layer: 'back' (দেয়াল/জানালা) বা 'front' (সিটের পিঠ ও রেলিং)
export const BusInterior: React.FC<{f: number; layer: 'back' | 'front'; moving?: boolean}> = ({f, layer, moving = true}) => {
  const off = moving ? (f * 7) % 360 : 0;
  if (layer === 'back') {
    return (
      <Full>
        <defs>
          <clipPath id="win"><rect x={20} y={150} width={680} height={290} rx={18} /></clipPath>
        </defs>
        <rect width={W} height={H} fill="#f0e0bb" />
        <rect width={W} height={130} fill="#d9c493" />
        <rect y={126} width={W} height={10} fill="#b79a5a" />
        <rect x={10} y={140} width={700} height={310} rx={24} fill="#8a5a3a" stroke={INK} strokeWidth={5} />
        <g clipPath="url(#win)">
          <rect x={20} y={150} width={680} height={290} fill="#9fd8f2" />
          <circle cx={560} cy={210} r={36} fill="#ffe27a" />
          <rect x={20} y={340} width={680} height={100} fill="#7bbf6a" />
          {[0, 1, 2, 3].map((i) => {
            const x = ((i * 240 - off * 1.3) % 960 + 960) % 960 - 120;
            return <Tree key={i} x={x} y={330} s={1.4} />;
          })}
          {[0, 1, 2].map((i) => {
            const x = ((i * 360 - off * 2.4) % 1080 + 1080) % 1080 - 150;
            return <g key={'p' + i}><rect x={x} y={200} width={8} height={240} fill="#555" /><rect x={x - 22} y={214} width={52} height={7} fill="#555" /></g>;
          })}
        </g>
        {[246, 480].map((x) => <rect key={x} x={x} y={140} width={14} height={310} fill="#8a5a3a" stroke={INK} strokeWidth={4} />)}
        <rect y={450} width={W} height={20} fill="#b79a5a" />
        <rect y={1010} width={W} height={270} fill="#6e5238" />
        {Array.from({length: 7}).map((_, i) => <rect key={i} x={i * 110 - 20} y={1010} width={6} height={270} fill="#5a432c" />)}
        <rect x={0} y={1000} width={W} height={14} fill="#4b3827" />
      </Full>
    );
  }
  return (
    <Full>
      {[20, 270, 520].map((x, i) => (
        <g key={x}>
          <rect x={x} y={700} width={190} height={190} rx={34} fill={i === 1 ? '#a23a3a' : '#8c2f3c'} stroke={INK} strokeWidth={5} />
          <rect x={x + 18} y={716} width={154} height={40} rx={14} fill="#b34a55" opacity={0.7} />
        </g>
      ))}
      <rect x={0} y={829} width={W} height={12} rx={6} fill="#d4af37" stroke={INK} strokeWidth={4} />
    </Full>
  );
};

// ঘর — dawn/night
export const Home: React.FC<{f: number; night: number}> = ({night}) => {
  const wall = night > 0.5 ? '#3a4366' : '#f5e3bd';
  const sky = night > 0.5 ? '#1b2447' : '#ffb26b';
  return (
    <Full>
      <rect width={W} height={H} fill={wall} />
      <rect y={1000} width={W} height={280} fill={night > 0.5 ? '#2a2f4a' : '#b98a5a'} />
      <rect y={990} width={W} height={14} fill={night > 0.5 ? '#1f2338' : '#8c6540'} />
      <rect x={60} y={260} width={260} height={300} rx={14} fill="#7a4a2a" stroke={INK} strokeWidth={5} />
      <rect x={76} y={276} width={228} height={268} fill={sky} />
      {night > 0.5 ? (
        <g>
          <circle cx={240} cy={340} r={34} fill="#f6f1c8" />
          {[[110, 320], [170, 400], [280, 470], [130, 480]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={3} fill="#fff" />)}
        </g>
      ) : (
        <g>
          <circle cx={190} cy={520} r={80} fill="#ffe27a" />
          <rect x={76} y={500} width={228} height={44} fill="#e8873a" opacity={0.6} />
        </g>
      )}
      <line x1={190} y1={276} x2={190} y2={544} stroke="#7a4a2a" strokeWidth={8} />
      <line x1={76} y1={410} x2={304} y2={410} stroke="#7a4a2a" strokeWidth={8} />
      <rect x={470} y={820} width={220} height={20} rx={8} fill="#7a4a2a" stroke={INK} strokeWidth={4} />
      <rect x={490} y={840} width={16} height={160} fill="#7a4a2a" stroke={INK} strokeWidth={3} />
      <rect x={654} y={840} width={16} height={160} fill="#7a4a2a" stroke={INK} strokeWidth={3} />
      <rect x={410} y={100} width={240} height={70} rx={10} fill="none" />
      <path d="M0 0 L0 110 Q80 140 160 110 L160 0 Z" fill={night > 0.5 ? '#46325a' : '#b33a3a'} opacity={0.85} />
    </Full>
  );
};

// রাস্তা/বাসস্ট্যান্ড
export const Street: React.FC<{f: number; tone: 'dusk' | 'day'; sign?: boolean}> = ({f, tone, sign}) => {
  const sky = tone === 'dusk' ? ['#f0a05a', '#fbd38d'] : ['#7cc8ef', '#d8f0fb'];
  const bld = tone === 'dusk' ? ['#6a4a63', '#85566f', '#5a3f58'] : ['#d8b98a', '#c9a074', '#e3c9a0'];
  return (
    <Full>
      <defs>
        <linearGradient id="sk" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={sky[0]} />
          <stop offset="1" stopColor={sky[1]} />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill="url(#sk)" />
      <circle cx={560} cy={260} r={60} fill={tone === 'dusk' ? '#ffd27a' : '#fff3b0'} opacity={0.9} />
      {[0, 1, 2].map((i) => (
        <g key={i}>
          <rect x={-10 + i * 250} y={420 - (i % 2) * 90} width={240} height={620 + (i % 2) * 90} fill={bld[i]} stroke={INK} strokeWidth={4} />
          {Array.from({length: 5}).map((_, r) => [0, 1].map((c) => (
            <rect key={r + '-' + c} x={20 + i * 250 + c * 100} y={470 - (i % 2) * 90 + r * 100} width={60} height={54} rx={4} fill={tone === 'dusk' ? '#ffd86a' : '#9fd0e8'} stroke={INK} strokeWidth={3} />
          )))}
        </g>
      ))}
      {sign && (
        <g>
          <rect x={150} y={330} width={420} height={70} rx={10} fill="#1f5a3a" stroke={INK} strokeWidth={5} />
          <rect x={160} y={340} width={400} height={50} rx={6} fill="none" stroke="#fff" strokeWidth={2} />
        </g>
      )}
      <rect y={1030} width={W} height={30} fill="#b8b0a0" stroke={INK} strokeWidth={4} />
      <rect y={1060} width={W} height={220} fill="#4a4a52" />
      {Array.from({length: 6}).map((_, i) => {
        const x = ((i * 160 - f * 5) % 960 + 960) % 960 - 120;
        return <rect key={i} x={x} y={1160} width={90} height={12} rx={4} fill="#f3eee2" />;
      })}
    </Full>
  );
};

// গ্যারেজ
export const Garage: React.FC<{f: number; day: number}> = ({f, day}) => {
  const sway = Math.sin(f / 18) * 10;
  return (
    <Full>
      <rect width={W} height={H} fill="#7d838d" />
      {Array.from({length: 13}).map((_, r) => (
        <g key={r}>
          <line x1={0} y1={r * 100} x2={W} y2={r * 100} stroke="#666c76" strokeWidth={4} />
          {Array.from({length: 6}).map((_, c) => (
            <line key={c} x1={(r % 2 ? 60 : 0) + c * 130} y1={r * 100} x2={(r % 2 ? 60 : 0) + c * 130} y2={r * 100 + 100} stroke="#666c76" strokeWidth={3} />
          ))}
        </g>
      ))}
      <rect x={470} y={220} width={190} height={240} rx={10} fill={day > 0.5 ? '#9fd8f2' : '#1b2447'} stroke={INK} strokeWidth={6} />
      {day > 0.5 ? <circle cx={560} cy={400} r={36} fill="#ffe27a" /> : <circle cx={600} cy={290} r={24} fill="#f6f1c8" />}
      <line x1={565} y1={220} x2={565} y2={460} stroke={INK} strokeWidth={5} />
      <line x1={470} y1={340} x2={660} y2={340} stroke={INK} strokeWidth={5} />
      <line x1={190} y1={0} x2={190} y2={120} stroke={INK} strokeWidth={4} />
      <g transform={`rotate(${sway * 0.4} 190 120)`}>
        <path d="M168 120 L212 120 L226 170 L154 170 Z" fill="#3a3a3a" stroke={INK} strokeWidth={4} />
        <circle cx={190} cy={178} r={18} fill="#ffe27a" stroke={INK} strokeWidth={3} />
        <circle cx={190} cy={178} r={70} fill="#ffe27a" opacity={0.18} />
      </g>
      <rect x={30} y={560} width={250} height={14} fill="#5a432c" stroke={INK} strokeWidth={4} />
      {['#d8362f', '#3a7a9a', '#f2b92f', '#6a6a6a'].map((c, i) => <rect key={i} x={48 + i * 56} y={510} width={36} height={50} rx={6} fill={c} stroke={INK} strokeWidth={3} />)}
      <rect y={1030} width={W} height={250} fill="#4a4a50" />
      <rect y={1022} width={W} height={12} fill="#2f2f33" />
      <ellipse cx={170} cy={1150} rx={90} ry={16} fill="#2b2b2b" opacity={0.5} />
    </Full>
  );
};

export const MotionBg: React.FC<{c1?: string; c2?: string; f?: number}> = ({c1 = '#1d5a45', c2 = '#0e2e25', f = 0}) => (
  <Full>
    <defs>
      <radialGradient id="mg" cx="50%" cy="45%" r="75%">
        <stop offset="0" stopColor={c1} />
        <stop offset="1" stopColor={c2} />
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill="url(#mg)" />
    {Array.from({length: 9}).map((_, i) => {
      const x = (i * 97 + 40) % 720;
      const y = ((i * 211 + 100 - f * (0.4 + (i % 3) * 0.2)) % 1400 + 1400) % 1400 - 60;
      return <circle key={i} cx={x} cy={y} r={30 + (i % 4) * 22} fill="#fff" opacity={0.05 + (i % 3) * 0.02} />;
    })}
  </Full>
);

// ছোট হেল্পার: কুয়াশা/স্লো ফেড
export const Dim: React.FC<{amount: number}> = ({amount}) => (
  <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, background: `rgba(10,10,30,${clamp01(amount)})`}} />
);
